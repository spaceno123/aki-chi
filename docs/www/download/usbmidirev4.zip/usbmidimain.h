/*
	USB MIDI Main Header File
*/
#ifndef USBMIDIMAIN_H
#define USBMIDIMAIN_H

void usbmidimain(void);

#endif	/* USBMIDIMAIN_H */
